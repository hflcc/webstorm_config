<template>
  <div class="page">
   
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';

  export default defineComponent({
    name: '',
    components: {},
    setup() {
      return {};
    }
  });
</script>

<style lang="less">
  
</style>
