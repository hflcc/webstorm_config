/**
 * Created by ${USER} on ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
 */
<template>
#[[$END$]]#
</template>

<script>
export default {
  name: "${COMPONENT_NAME}",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped lang="less">

</style>